# Architecture Overview

## System Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend                             │
│   Cesium 3-D  ·  Dashboard Metrics  ·  Chart.js Timelines  │
└──────────────────────────┬──────────────────────────────────┘
                           │  HTTP / JSON
┌──────────────────────────▼──────────────────────────────────┐
│                     FastAPI Backend                          │
│                                                              │
│  ┌─────────┐   ┌──────────────────────────────────────────┐ │
│  │  Auth   │   │          API  Routes  (/api/v1)          │ │
│  │  JWT    │──▶│  /simulate  /step  /iot  /dsp  /fft     │ │
│  └─────────┘   └────┬─────────┬────────┬────────┬────────┘ │
│                      │         │        │        │          │
│         ┌────────────▼──┐  ┌───▼────┐ ┌─▼──────┐ ┌▼──────┐ │
│         │  H₂ Engine    │  │  IoT   │ │  DSP   │ │  FFT  │ │
│         │  (SimPy)      │  │Sensors │ │Signals │ │Anomaly│ │
│         │ ┌───────────┐ │  │        │ │        │ │Detect │ │
│         │ │Electrolyzer│ │  │ DHT11  │ │ AM mod │ │       │ │
│         │ │Storage     │ │  │ LDR    │ │ Radar  │ │Cooley-│ │
│         │ │Power Prof. │ │  │ Stack  │ │ Filter │ │Tukey  │ │
│         │ └───────────┘ │  │ Queue  │ │ Demod  │ │       │ │
│         └───────────────┘  └────────┘ └────────┘ └───────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Module Responsibilities

| Module                          | Source       | Role                                              |
|---------------------------------|--------------|----------------------------------------------------|
| `app.auth.token`                | original     | JWT decode & verification                          |
| `app.models.schemas`            | original     | Pydantic request/response validation               |
| `app.models.electrolyzer`       | original     | PEM electrolyzer physics model                     |
| `app.simulation.engine`         | original     | SimPy H₂ production orchestration                  |
| `app.simulation.power`          | original     | Solar/wind stochastic generation curves            |
| `app.simulation.storage`        | original     | Bounded hydrogen tank model                        |
| `app.simulation.iot_sensors`    | jose1iot5    | Simulated DHT11 + LDR with stack/queue/hashmap     |
| `app.simulation.dsp_signals`    | ---.docx     | AM modulation, AWGN, demod, radar, components      |
| `app.simulation.fft_analysis`   | C++ FFT doc  | FFT spectrum analysis & anomaly detection           |
| `app.services.hydrogen`         | original     | Single-step plant telemetry service                |
| `app.api.routes`                | merged       | All REST endpoint definitions                      |
| `app.config`                    | original     | Centralised env-based settings                     |

## Data Flow per Endpoint

### POST /api/v1/simulate  (Hydrogen)
1. Validate request → create SimPy environment + electrolyzer + storage
2. Each hour: renewable power → electrolyzer.step() → storage.store()
3. Return hourly data points + summary statistics

### POST /api/v1/iot  (IoT Sensors)
1. Loop N hours → simulate temp (diurnal + noise) + light (solar curve)
2. Push readings to stack (LIFO) and queue (FIFO)
3. Classify via hashmap → compute LED state → drain queue
4. Return readings array + summary (averages, LED on-time, special events)

### POST /api/v1/dsp  (Signal Processing)
1. Generate modulating + carrier signals from parameters
2. AM modulate → add AWGN noise → envelope detect → LPF recover
3. Radar branch: generate tone → resample → DC block
4. Component chain: amplify → gate → envelope shape
5. Compute statistics → downsample arrays → return JSON

### POST /api/v1/fft  (FFT Anomaly Detection)
1. Generate composite sensor signal (or accept external signal)
2. Compute FFT (NumPy Cooley-Tukey) → positive-half magnitudes
3. Find peaks above threshold → flag those above anomaly frequency
4. Return time-domain signal, spectrum, peaks, and alert status
