"""DSP signal processing pipeline.

Implements the mathematical signal processing system:
  - AM modulation:  s(t) = (1 + ka·m(t)) · c(t)
  - AWGN noise:     s_noisy = s + w,  w ~ N(0, σ²)
  - Envelope detection + Butterworth LPF demodulation
  - Radar signal simulation with resampling & DC blocking
  - Amplifier, gate, envelope shaping components
  - Statistical analysis

All functions operate on NumPy arrays for backend computation.
Matplotlib is NOT imported — the API returns raw data arrays
so the frontend can render charts.
"""

from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.signal import butter, lfilter, resample


# =====================================================================
#  1. CORE SIGNAL GENERATORS
# =====================================================================

def time_vector(fs: float, duration: float) -> np.ndarray:
    """t[n] = n / Fs"""
    return np.arange(0, duration, 1.0 / fs)


def modulating_signal(t: np.ndarray, am: float, fm: float) -> np.ndarray:
    """m(t) = Am · sin(2π Fm t)"""
    return am * np.sin(2 * np.pi * fm * t)


def carrier_signal(t: np.ndarray, ac: float, fc: float) -> np.ndarray:
    """c(t) = Ac · sin(2π Fc t)"""
    return ac * np.sin(2 * np.pi * fc * t)


# =====================================================================
#  2. AM MODULATION
# =====================================================================

def amplitude_modulation(
    m: np.ndarray, c: np.ndarray, ka: float = 1.0
) -> np.ndarray:
    """s(t) = (1 + ka · m(t)) · c(t)"""
    return (1 + ka * m) * c


# =====================================================================
#  3. NOISE MODEL (AWGN)
# =====================================================================

def add_awgn(signal: np.ndarray, sigma: float = 0.1) -> np.ndarray:
    """s_noisy = s + w,  w ~ N(0, σ²)"""
    return signal + sigma * np.random.randn(len(signal))


# =====================================================================
#  4. DEMODULATION
# =====================================================================

def envelope_detection(signal: np.ndarray) -> np.ndarray:
    """|s(t)| — rectification-based envelope."""
    return np.abs(signal)


def lowpass_filter(
    signal: np.ndarray, cutoff: float, fs: float, order: int = 5
) -> np.ndarray:
    """Butterworth low-pass filter."""
    nyq = 0.5 * fs
    b, a = butter(order, cutoff / nyq, btype="low")
    return lfilter(b, a, signal)


# =====================================================================
#  5. RADAR SIGNAL PROCESSING
# =====================================================================

def radar_signal(t: np.ndarray, frequency: float) -> np.ndarray:
    """r(t) = sin(2π f t)"""
    return np.sin(2 * np.pi * frequency * t)


def rational_resampler(signal: np.ndarray, ratio: float) -> np.ndarray:
    """Resample by a rational ratio."""
    return resample(signal, int(len(signal) * ratio))


def dc_blocker(signal: np.ndarray) -> np.ndarray:
    """Remove DC offset."""
    return signal - np.mean(signal)


# =====================================================================
#  6. COMPONENT MODELS
# =====================================================================

def amplifier(signal: np.ndarray, gain: float) -> np.ndarray:
    """y = G · x"""
    return gain * signal


def gate(signal: np.ndarray, threshold: float) -> np.ndarray:
    """Hard thresholding."""
    return np.where(np.abs(signal) > threshold, signal, 0)


def envelope_shaping(signal: np.ndarray, alpha: float = 0.01) -> np.ndarray:
    """Exponential envelope shaping."""
    n = np.arange(len(signal))
    return signal * (1 - np.exp(-alpha * n))


# =====================================================================
#  7. STATISTICS
# =====================================================================

def signal_statistics(signal: np.ndarray) -> dict:
    return {
        "mean": float(np.mean(signal)),
        "std": float(np.std(signal)),
        "min": float(np.min(signal)),
        "max": float(np.max(signal)),
        "rms": float(np.sqrt(np.mean(signal ** 2))),
    }


# =====================================================================
#  8. FULL DSP PIPELINE
# =====================================================================

def run_dsp_pipeline(
    fs: int = 10_000,
    duration: float = 1.0,
    am_amplitude: float = 1.0,
    carrier_amplitude: float = 1.0,
    fm: float = 10.0,
    fc: float = 1000.0,
    noise_sigma: float = 0.2,
    radar_freq: float = 200.0,
    radar_resample_ratio: float = 0.5,
    amp_gain: float = 2.0,
    gate_threshold: float = 0.2,
    envelope_alpha: float = 0.01,
    downsample: int = 10,
) -> Dict:
    """Execute the complete AM + Radar DSP pipeline.

    Parameters
    ----------
    fs : int
        Sampling frequency (Hz).
    duration : float
        Signal duration (seconds).
    fm, fc : float
        Modulating / carrier frequencies.
    noise_sigma : float
        AWGN standard deviation.
    radar_freq : float
        Radar tone frequency.
    downsample : int
        Return every Nth sample to keep JSON payload small.

    Returns
    -------
    dict  with keys: time, signals (dict of arrays), stats, params.
    """
    # Time axis
    t = time_vector(fs, duration)

    # Generate base signals
    m = modulating_signal(t, am_amplitude, fm)
    c = carrier_signal(t, carrier_amplitude, fc)

    # AM modulation + noise
    s = amplitude_modulation(m, c)
    s_noisy = add_awgn(s, sigma=noise_sigma)

    # Demodulation
    env = envelope_detection(s_noisy)
    recovered = lowpass_filter(env, cutoff=fm, fs=fs)

    # Radar branch
    r = radar_signal(t, radar_freq)
    r_resampled = rational_resampler(r, radar_resample_ratio)
    r_clean = dc_blocker(r_resampled)

    # Component chain
    amplified = amplifier(recovered, gain=amp_gain)
    gated = gate(amplified, threshold=gate_threshold)
    shaped = envelope_shaping(gated, alpha=envelope_alpha)

    # Downsample for JSON transport
    def ds(arr):
        return arr[::downsample].tolist()

    return {
        "params": {
            "fs": fs, "duration": duration,
            "fm": fm, "fc": fc,
            "noise_sigma": noise_sigma, "radar_freq": radar_freq,
        },
        "time": ds(t),
        "signals": {
            "modulating": ds(m),
            "carrier": ds(c),
            "am_modulated": ds(s),
            "am_noisy": ds(s_noisy),
            "envelope": ds(env),
            "recovered": ds(recovered),
            "radar_raw": r[::downsample].tolist(),
            "radar_processed": r_clean[:: max(1, downsample // 2)].tolist(),
            "amplified": ds(amplified),
            "gated": ds(gated),
            "shaped": ds(shaped),
        },
        "stats": {
            "am_noisy": signal_statistics(s_noisy),
            "recovered": signal_statistics(recovered),
            "radar_processed": signal_statistics(r_clean),
            "final_shaped": signal_statistics(shaped),
        },
    }
