"""Bounded-capacity hydrogen storage tank."""


class HydrogenStorage:
    """Simple tank that clamps at a maximum capacity.

    Parameters
    ----------
    capacity_kg : float
        Maximum hydrogen the tank can hold (kg).
    """

    def __init__(self, capacity_kg: float = 2000.0):
        self.capacity_kg = capacity_kg
        self.level: float = 0.0

    def store(self, amount_kg: float) -> float:
        """Add hydrogen; returns actual amount stored (may be clamped)."""
        actual = min(amount_kg, self.capacity_kg - self.level)
        self.level += actual
        return actual

    @property
    def fill_fraction(self) -> float:
        return self.level / self.capacity_kg if self.capacity_kg > 0 else 0.0
