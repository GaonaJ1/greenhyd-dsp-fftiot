"""IoT sensor monitoring simulation.

Software emulation of the Raspberry Pi-based system from jose1iot5:
  - DHT11 temperature sensor  →  simulated with noise model
  - LDR light sensor           →  simulated with day/night curve
  - Stack (LIFO), Queue (FIFO), Hashmap classification
  - LED actuator logic based on thresholds
"""

import math
import random
import time
from collections import deque
from dataclasses import dataclass, field
from typing import List, Optional


# ── Classification hashmap ────────────────────────────────────────────────────
LEVEL_MAP = {0: "very_low", 1: "low", 2: "medium", 3: "high"}

# ── Threshold constants ──────────────────────────────────────────────────────
SPECIAL_LIGHT_THRESHOLD = 7.888
TEMP_LED_THRESHOLD = 30.0
LIGHT_LED_THRESHOLD = 3.0


def _classify(value: float) -> str:
    """Hashmap-based classification f(x)."""
    level = max(0, min(3, int(value)))
    return LEVEL_MAP.get(level, "unknown")


# ── Simulated sensors ────────────────────────────────────────────────────────

def _sim_temperature(hour: int, base: float = 25.0) -> float:
    """Simulate DHT11 temperature with diurnal cycle + noise."""
    diurnal = 5.0 * math.sin(math.pi * ((hour % 24) - 6) / 12)
    noise = random.gauss(0, 0.5)
    return round(base + diurnal + noise, 2)


def _sim_light(hour: int) -> float:
    """Simulate LDR light level (0-10 scale). Dark at night, bright midday."""
    h = hour % 24
    if 6 <= h <= 18:
        base = 8.0 * math.sin(math.pi * (h - 6) / 12)
    else:
        base = 0.3
    return round(max(0, base + random.gauss(0, 0.4)), 3)


# ── Sensor reading data ──────────────────────────────────────────────────────

@dataclass
class SensorReading:
    time_h: int
    temperature: float
    temp_class: str
    light: float
    light_class: str
    led_state: bool
    special_condition: bool


@dataclass
class IoTSimulationState:
    """Holds stack / queue state across the run."""
    stack: list = field(default_factory=list)
    queue: deque = field(default_factory=deque)


def run_iot_simulation(
    hours: int = 48,
    temp_base: float = 25.0,
    temp_threshold: float = TEMP_LED_THRESHOLD,
    light_threshold: float = LIGHT_LED_THRESHOLD,
) -> List[dict]:
    """Run the full IoT sensor monitoring simulation.

    Returns one dict per simulated hour with sensor readings,
    classification, LED state, and data-structure snapshots.
    """
    state = IoTSimulationState()
    results: List[dict] = []

    for h in range(hours):
        temperature = _sim_temperature(h, temp_base)
        light = _sim_light(h)

        # Stack push
        state.stack.append({"temp": temperature, "light": light})

        # Queue push (FIFO processing)
        state.queue.append(("temp", temperature))
        state.queue.append(("light", light))

        # Special condition check
        special = abs(light - SPECIAL_LIGHT_THRESHOLD) < 0.1

        # LED logic
        led = temperature > temp_threshold or light < light_threshold

        # Process queue (drain)
        processed = []
        while state.queue:
            sensor, val = state.queue.popleft()
            name = "temperature_sensor" if sensor == "temp" else "light_sensor"
            processed.append({
                "sensor": name,
                "value": round(val, 3),
                "classification": _classify(val),
            })

        reading = {
            "time_h": h,
            "temperature": temperature,
            "temp_class": _classify(temperature / 10),  # scale to 0-3 range
            "light": light,
            "light_class": _classify(light / 2.5),       # scale to 0-3 range
            "led_state": led,
            "special_condition": special,
            "queue_processed": processed,
            "stack_depth": len(state.stack),
            "stack_last5": state.stack[-5:],
        }
        results.append(reading)

    return results
