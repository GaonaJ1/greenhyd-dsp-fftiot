"""SimPy-based discrete-event simulation of the hydrogen plant."""

from typing import Callable, List, Optional

import simpy

from app.config import settings
from app.models.electrolyzer import PEMElectrolyzer
from app.simulation.power import solar_wind_profile
from app.simulation.storage import HydrogenStorage


def _plant_process(
    env: simpy.Environment,
    electrolyzer: PEMElectrolyzer,
    storage: HydrogenStorage,
    results: list,
    power_fn: Callable[[int], float],
):
    """SimPy generator: one iteration = one hour of plant operation."""
    while True:
        power = power_fn(env.now)
        step = electrolyzer.step(power)
        storage.store(step["h2_produced_kg"])

        results.append({
            "time_h": env.now,
            "power_kw": power,
            "h2_produced_kg": step["h2_produced_kg"],
            "h2_total_kg": step["h2_total_kg"],
            "storage_level_kg": round(storage.level, 4),
            "efficiency": step["efficiency"],
        })
        yield env.timeout(1)


def run_simulation(
    hours: Optional[int] = None,
    rated_power_kw: Optional[float] = None,
    efficiency: Optional[float] = None,
    storage_capacity_kg: Optional[float] = None,
    power_fn: Optional[Callable[[int], float]] = None,
) -> List[dict]:
    """Execute a full simulation run.

    Parameters
    ----------
    hours : int
        Number of hours to simulate (default from settings).
    rated_power_kw, efficiency, storage_capacity_kg :
        Override electrolyzer / storage defaults.
    power_fn : callable(hour) -> float
        Renewable power generation function.

    Returns
    -------
    list[dict]
        One dict per simulated hour.
    """
    hours = hours or settings.sim_hours
    electrolyzer = PEMElectrolyzer(
        rated_power_kw=rated_power_kw or settings.electrolyzer_power_kw,
        efficiency=efficiency or settings.electrolyzer_efficiency,
    )
    storage = HydrogenStorage(
        capacity_kg=storage_capacity_kg or settings.storage_capacity_kg,
    )
    power_fn = power_fn or solar_wind_profile

    env = simpy.Environment()
    results: List[dict] = []
    env.process(_plant_process(env, electrolyzer, storage, results, power_fn))
    env.run(until=hours)
    return results
