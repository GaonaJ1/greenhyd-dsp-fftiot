"""Stochastic renewable power generation profiles."""

import math
import random


def solar_wind_profile(hour: int) -> float:
    """Return combined solar + wind power for a given hour of day.

    Uses a sinusoidal solar curve peaked at noon, plus a random wind
    component, to produce a more realistic renewable energy profile.
    """
    hour_of_day = hour % 24
    # Solar: peaks at hour 12, zero at night
    solar = max(0, 400 * math.sin(math.pi * (hour_of_day - 6) / 12)) if 6 <= hour_of_day <= 18 else 0.0
    # Wind: random baseline with gusts
    wind = random.uniform(100, 350) + random.uniform(-30, 30)
    return round(max(solar + wind, 0.0), 2)


def constant_profile(_hour: int, power_kw: float = 500.0) -> float:
    """Flat power supply (useful for testing)."""
    return power_kw
