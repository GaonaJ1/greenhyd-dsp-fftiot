"""FFT-based IoT anomaly detection.

Python port of the C++ Cooley-Tukey FFT system:
  - Generates composite sensor signals (vibration-like)
  - Performs FFT via NumPy (production-grade Cooley-Tukey)
  - Analyses frequency spectrum for dominant components
  - Detects high-frequency anomalies above a configurable threshold

The module can process both synthetic and externally supplied signals.
"""

from typing import Dict, List, Optional, Tuple

import numpy as np


# =====================================================================
#  1. SIGNAL GENERATION
# =====================================================================

def generate_sensor_signal(
    n: int = 64,
    sample_rate: float = 100.0,
    frequencies: Optional[List[Tuple[float, float]]] = None,
    noise_level: float = 0.0,
) -> Tuple[np.ndarray, np.ndarray]:
    """Generate a composite sensor signal (vibration-like).

    Parameters
    ----------
    n : int
        Number of samples (ideally a power of 2).
    sample_rate : float
        Sampling rate in Hz.
    frequencies : list of (freq_hz, amplitude)
        Sine components.  Default: 5 Hz (normal) + 20 Hz (anomaly).
    noise_level : float
        Std-dev of additive Gaussian noise.

    Returns
    -------
    t : ndarray   — time axis
    signal : ndarray — composite signal
    """
    if frequencies is None:
        frequencies = [(5.0, 1.0), (20.0, 0.5)]

    t = np.arange(n) / sample_rate
    signal = np.zeros(n)
    for freq, amp in frequencies:
        signal += amp * np.sin(2 * np.pi * freq * t)

    if noise_level > 0:
        signal += noise_level * np.random.randn(n)

    return t, signal


# =====================================================================
#  2. FFT COMPUTATION
# =====================================================================

def compute_fft(signal: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Compute the FFT and return magnitudes + phase.

    Uses NumPy's optimised FFT (Cooley-Tukey under the hood).
    Only the positive-frequency half is returned.
    """
    spectrum = np.fft.fft(signal)
    n = len(signal)
    half = n // 2
    magnitudes = np.abs(spectrum[:half]) * 2.0 / n  # normalised
    phases = np.angle(spectrum[:half])
    return magnitudes, phases


def frequency_axis(n: int, sample_rate: float) -> np.ndarray:
    """Return the frequency bins for the positive half of the FFT."""
    return np.fft.fftfreq(n, d=1.0 / sample_rate)[: n // 2]


# =====================================================================
#  3. SPECTRUM ANALYSIS & ANOMALY DETECTION
# =====================================================================

def analyze_spectrum(
    magnitudes: np.ndarray,
    freqs: np.ndarray,
    anomaly_freq_threshold: float = 15.0,
    magnitude_threshold: float = 0.1,
) -> Dict:
    """Analyse the FFT magnitude spectrum.

    Parameters
    ----------
    magnitudes : ndarray
        Positive-half magnitude spectrum.
    freqs : ndarray
        Corresponding frequency bins.
    anomaly_freq_threshold : float
        Frequencies above this value are considered anomalous.
    magnitude_threshold : float
        Ignore peaks below this magnitude.

    Returns
    -------
    dict with dominant frequency, peaks, anomalies, and alert flag.
    """
    # Find all peaks above threshold
    peaks = []
    for i, (mag, f) in enumerate(zip(magnitudes, freqs)):
        if mag > magnitude_threshold:
            peaks.append({
                "index": int(i),
                "frequency_hz": round(float(f), 4),
                "magnitude": round(float(mag), 6),
                "is_anomaly": float(f) > anomaly_freq_threshold,
            })

    # Dominant frequency
    dom_idx = int(np.argmax(magnitudes))
    dominant = {
        "index": dom_idx,
        "frequency_hz": round(float(freqs[dom_idx]), 4),
        "magnitude": round(float(magnitudes[dom_idx]), 6),
    }

    # Anomaly detection
    anomalies = [p for p in peaks if p["is_anomaly"]]
    alert = len(anomalies) > 0

    return {
        "dominant": dominant,
        "peaks": peaks,
        "anomalies": anomalies,
        "alert": alert,
        "alert_message": (
            "High-frequency anomaly detected at "
            + ", ".join(str(a["frequency_hz"]) + " Hz" for a in anomalies)
            if alert else "No anomalies detected"
        ),
    }


# =====================================================================
#  4. FULL FFT PIPELINE
# =====================================================================

def run_fft_analysis(
    n: int = 256,
    sample_rate: float = 100.0,
    frequencies: Optional[List[Tuple[float, float]]] = None,
    noise_level: float = 0.0,
    anomaly_freq_threshold: float = 15.0,
    magnitude_threshold: float = 0.05,
    external_signal: Optional[List[float]] = None,
) -> Dict:
    """Run the complete FFT anomaly-detection pipeline.

    Parameters
    ----------
    n : int
        Samples (power of 2 recommended).
    sample_rate : float
        Hz.
    frequencies : list[(hz, amplitude)]
        Tone components for synthetic signal.
    noise_level : float
        AWGN σ.
    anomaly_freq_threshold : float
        Hz above which a peak is flagged.
    external_signal : list[float] | None
        If provided, analyse this instead of generating a synthetic one.

    Returns
    -------
    dict  with time-domain signal, frequency spectrum, analysis results.
    """
    if external_signal is not None:
        signal = np.array(external_signal, dtype=float)
        n = len(signal)
        t = (np.arange(n) / sample_rate).tolist()
    else:
        t_arr, signal = generate_sensor_signal(n, sample_rate, frequencies, noise_level)
        t = t_arr.tolist()

    magnitudes, phases = compute_fft(signal)
    freqs = frequency_axis(n, sample_rate)

    analysis = analyze_spectrum(
        magnitudes, freqs,
        anomaly_freq_threshold=anomaly_freq_threshold,
        magnitude_threshold=magnitude_threshold,
    )

    return {
        "params": {
            "n": n,
            "sample_rate": sample_rate,
            "noise_level": noise_level,
            "anomaly_freq_threshold": anomaly_freq_threshold,
        },
        "time_domain": {
            "time": t,
            "signal": signal.tolist(),
        },
        "frequency_domain": {
            "frequencies": freqs.tolist(),
            "magnitudes": magnitudes.tolist(),
            "phases": phases.tolist(),
        },
        "analysis": analysis,
    }
