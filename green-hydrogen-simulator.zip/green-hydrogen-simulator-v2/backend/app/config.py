"""Centralised application settings loaded from environment / .env file."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── Auth ───────────────────────────────────
    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"

    # ── Server ─────────────────────────────────
    api_port: int = 8000
    cors_origins: str = "*"

    # ── Simulation defaults ───────────────────
    sim_hours: int = 48
    electrolyzer_power_kw: float = 500.0
    electrolyzer_efficiency: float = 0.72
    storage_capacity_kg: float = 2000.0

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
