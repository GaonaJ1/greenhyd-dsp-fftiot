"""REST API routes for the Green Hydrogen Simulator.

Endpoint groups
───────────────
/api/v1/step        — single-tick plant telemetry (live dashboard)
/api/v1/simulate    — multi-hour H₂ production simulation (SimPy)
/api/v1/iot         — IoT sensor monitoring simulation
/api/v1/dsp         — AM modulation + radar DSP pipeline
/api/v1/fft         — FFT spectrum analysis & anomaly detection
"""

from fastapi import APIRouter, Depends

from app.auth.token import verify_token
from app.models.schemas import (
    DSPRequest,
    FFTRequest,
    IoTSimulationRequest,
    IoTSimulationResult,
    SimulationPoint,
    SimulationRequest,
    SimulationResult,
    SystemSnapshot,
)
from app.services.hydrogen import HydrogenPlantService
from app.simulation.dsp_signals import run_dsp_pipeline
from app.simulation.engine import run_simulation
from app.simulation.fft_analysis import run_fft_analysis
from app.simulation.iot_sensors import run_iot_simulation

router = APIRouter(prefix="/api/v1")

# ── Shared state ──────────────────────────────────────────────────────────────
_plant = HydrogenPlantService()


# =====================================================================
#  HYDROGEN — original plant simulation
# =====================================================================

@router.get("/step", response_model=SystemSnapshot, tags=["hydrogen"])
def single_step(user: dict = Depends(verify_token)):
    """Return the next single-step plant snapshot (live-dashboard mode)."""
    return _plant.step()


@router.post("/simulate", response_model=SimulationResult, tags=["hydrogen"])
def simulate(
    req: SimulationRequest = SimulationRequest(),
    user: dict = Depends(verify_token),
):
    """Run a multi-hour discrete-event H₂ production simulation."""
    raw = run_simulation(
        hours=req.hours,
        rated_power_kw=req.rated_power_kw,
        efficiency=req.efficiency,
        storage_capacity_kg=req.storage_capacity_kg,
    )
    points = [SimulationPoint(**p) for p in raw]
    summary = {
        "total_h2_kg": points[-1].h2_total_kg if points else 0,
        "avg_efficiency": round(
            sum(p.efficiency for p in points) / len(points), 4
        ) if points else 0,
        "peak_power_kw": max((p.power_kw for p in points), default=0),
        "final_storage_kg": points[-1].storage_level_kg if points else 0,
        "hours_simulated": len(points),
    }
    return SimulationResult(points=points, summary=summary)


# =====================================================================
#  IoT SENSOR MONITORING  (jose1iot5)
# =====================================================================

@router.post("/iot", response_model=IoTSimulationResult, tags=["iot"])
def iot_simulation(
    req: IoTSimulationRequest = IoTSimulationRequest(),
    user: dict = Depends(verify_token),
):
    """Simulate IoT sensor readings (temperature + light).

    Emulates the Raspberry Pi DHT11 + LDR system with stack/queue/hashmap
    data structures and LED actuator logic.
    """
    readings = run_iot_simulation(
        hours=req.hours,
        temp_base=req.temp_base,
        temp_threshold=req.temp_threshold,
        light_threshold=req.light_threshold,
    )
    # Build summary
    temps = [r["temperature"] for r in readings]
    lights = [r["light"] for r in readings]
    led_on_hours = sum(1 for r in readings if r["led_state"])
    special_count = sum(1 for r in readings if r["special_condition"])

    summary = {
        "hours_simulated": len(readings),
        "temp_avg": round(sum(temps) / len(temps), 2),
        "temp_min": min(temps),
        "temp_max": max(temps),
        "light_avg": round(sum(lights) / len(lights), 3),
        "light_min": min(lights),
        "light_max": max(lights),
        "led_on_hours": led_on_hours,
        "led_on_pct": round(100 * led_on_hours / len(readings), 1),
        "special_condition_count": special_count,
    }
    return IoTSimulationResult(readings=readings, summary=summary)


# =====================================================================
#  DSP SIGNAL PROCESSING  (AM + Radar)
# =====================================================================

@router.post("/dsp", tags=["dsp"])
def dsp_pipeline(
    req: DSPRequest = DSPRequest(),
    user: dict = Depends(verify_token),
):
    """Run the AM modulation → noise → demodulation → radar pipeline.

    Returns time-domain & processed signals plus statistical analysis.
    """
    return run_dsp_pipeline(
        fs=req.fs,
        duration=req.duration,
        am_amplitude=req.am_amplitude,
        carrier_amplitude=req.carrier_amplitude,
        fm=req.fm,
        fc=req.fc,
        noise_sigma=req.noise_sigma,
        radar_freq=req.radar_freq,
        radar_resample_ratio=req.radar_resample_ratio,
        amp_gain=req.amp_gain,
        gate_threshold=req.gate_threshold,
        downsample=req.downsample,
    )


# =====================================================================
#  FFT ANOMALY DETECTION  (C++ port)
# =====================================================================

@router.post("/fft", tags=["fft"])
def fft_analysis(
    req: FFTRequest = FFTRequest(),
    user: dict = Depends(verify_token),
):
    """FFT-based frequency analysis and anomaly detection.

    Generates (or accepts) a sensor signal, computes the FFT,
    identifies dominant frequencies, and flags high-frequency anomalies.
    """
    freq_tuples = None
    if req.frequencies:
        freq_tuples = [(f.frequency_hz, f.amplitude) for f in req.frequencies]

    return run_fft_analysis(
        n=req.n,
        sample_rate=req.sample_rate,
        frequencies=freq_tuples,
        noise_level=req.noise_level,
        anomaly_freq_threshold=req.anomaly_freq_threshold,
        magnitude_threshold=req.magnitude_threshold,
        external_signal=req.external_signal,
    )
