"""Pydantic schemas for API request / response validation."""

from typing import Dict, List, Optional
from pydantic import BaseModel, Field


# ── Sub-models ────────────────────────────────────────────────────────────────

class EnergySource(BaseModel):
    power: float = Field(..., description="Power output in kW")
    voltage: float = Field(..., description="Voltage in V")


class ElectrolyzerState(BaseModel):
    current: float = Field(..., description="Operating current in A")
    hydrogen_rate: float = Field(..., description="H₂ production rate in kg/h")
    oxygen_rate: float = Field(..., description="O₂ production rate in kg/h")
    efficiency: float = Field(..., description="Current efficiency (0-1)")


class CFDState(BaseModel):
    pressure: float = Field(..., description="Pressure in Pa")
    velocity: float = Field(..., description="Flow velocity in m/s")


class ValveState(BaseModel):
    flow: float = Field(..., description="Flow rate in L/min")
    position: float = Field(..., description="Valve opening fraction (0-1)")


class CircuitState(BaseModel):
    current: float = Field(..., description="Current in A")
    voltage_drop: float = Field(..., description="Voltage drop in V")


class SensorReading(BaseModel):
    value: float
    unit: str
    timestamp: float
    sensor_id: str


# ── Top-level responses ──────────────────────────────────────────────────────

class SystemSnapshot(BaseModel):
    """Single time-step state of the entire plant."""
    energy: Dict[str, EnergySource]
    electrolyzer: ElectrolyzerState
    cfd: CFDState
    valves: Dict[str, ValveState]
    circuit: Dict[str, CircuitState]
    sensors: Dict[str, SensorReading]


class SimulationPoint(BaseModel):
    """One hourly data-point from the discrete-event simulation."""
    time_h: int
    power_kw: float
    h2_produced_kg: float
    h2_total_kg: float
    storage_level_kg: float
    efficiency: float


class SimulationRequest(BaseModel):
    hours: int = Field(default=48, ge=1, le=8760, description="Simulation horizon in hours")
    rated_power_kw: Optional[float] = Field(default=None, description="Electrolyzer rated power")
    efficiency: Optional[float] = Field(default=None, ge=0.3, le=1.0)
    storage_capacity_kg: Optional[float] = Field(default=None, ge=0)


class SimulationResult(BaseModel):
    points: List[SimulationPoint]
    summary: dict


# ── IoT Sensor Monitoring ────────────────────────────────────────────────────

class IoTSimulationRequest(BaseModel):
    hours: int = Field(default=48, ge=1, le=8760, description="Hours to simulate")
    temp_base: float = Field(default=25.0, description="Base temperature °C")
    temp_threshold: float = Field(default=30.0, description="LED-on temperature threshold")
    light_threshold: float = Field(default=3.0, description="LED-on light threshold (dark)")


class IoTSimulationResult(BaseModel):
    readings: List[dict]
    summary: dict


# ── DSP Signal Processing ───────────────────────────────────────────────────

class DSPRequest(BaseModel):
    fs: int = Field(default=10000, ge=1000, le=100000, description="Sampling frequency Hz")
    duration: float = Field(default=1.0, ge=0.01, le=10.0, description="Signal duration (s)")
    am_amplitude: float = Field(default=1.0, description="Modulating amplitude")
    carrier_amplitude: float = Field(default=1.0, description="Carrier amplitude")
    fm: float = Field(default=10.0, ge=1, description="Modulating frequency Hz")
    fc: float = Field(default=1000.0, ge=10, description="Carrier frequency Hz")
    noise_sigma: float = Field(default=0.2, ge=0, le=5.0, description="AWGN σ")
    radar_freq: float = Field(default=200.0, ge=1, description="Radar tone Hz")
    radar_resample_ratio: float = Field(default=0.5, gt=0, le=2.0)
    amp_gain: float = Field(default=2.0, description="Amplifier gain")
    gate_threshold: float = Field(default=0.2, ge=0, description="Gate threshold")
    downsample: int = Field(default=10, ge=1, le=100, description="Return every Nth sample")


# ── FFT Anomaly Detection ───────────────────────────────────────────────────

class FrequencyComponent(BaseModel):
    frequency_hz: float
    amplitude: float = 1.0


class FFTRequest(BaseModel):
    n: int = Field(default=256, ge=16, le=65536, description="Number of samples")
    sample_rate: float = Field(default=100.0, ge=1, description="Sample rate Hz")
    frequencies: Optional[List[FrequencyComponent]] = Field(
        default=None, description="Tone components; default 5 Hz + 20 Hz"
    )
    noise_level: float = Field(default=0.0, ge=0, le=5.0, description="AWGN σ")
    anomaly_freq_threshold: float = Field(default=15.0, ge=0, description="Alert above this Hz")
    magnitude_threshold: float = Field(default=0.05, ge=0, description="Ignore peaks below this")
    external_signal: Optional[List[float]] = Field(
        default=None, description="Analyse a custom signal instead of generating one"
    )
