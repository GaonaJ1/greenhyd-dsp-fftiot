"""PEM electrolyzer physical model with efficiency degradation."""


class PEMElectrolyzer:
    """Proton-Exchange Membrane electrolyzer.

    Models power-to-hydrogen conversion with a linear efficiency
    degradation curve over operating hours.

    Parameters
    ----------
    rated_power_kw : float
        Maximum electrical input the stack can accept (kW).
    efficiency : float
        Beginning-of-life electrical efficiency (0-1).
    degradation_rate : float
        Efficiency loss per operating hour.
    min_efficiency : float
        Hard floor – efficiency will not drop below this value.
    """

    H2_LHV_KWH_PER_KG = 33.33  # Lower heating value of hydrogen

    def __init__(
        self,
        rated_power_kw: float = 500.0,
        efficiency: float = 0.72,
        degradation_rate: float = 0.00002,
        min_efficiency: float = 0.55,
    ):
        self.rated_power_kw = rated_power_kw
        self.initial_efficiency = efficiency
        self.degradation_rate = degradation_rate
        self.min_efficiency = min_efficiency
        self.operating_hours: int = 0
        self.h2_total: float = 0.0

    @property
    def current_efficiency(self) -> float:
        return max(
            self.initial_efficiency - self.degradation_rate * self.operating_hours,
            self.min_efficiency,
        )

    def step(self, available_power_kw: float, dt: int = 1) -> dict:
        """Advance the electrolyzer by *dt* hours.

        Returns a dict with power consumed, efficiency, and H₂ produced.
        """
        self.operating_hours += dt
        efficiency = self.current_efficiency
        used_power = min(self.rated_power_kw, max(available_power_kw, 0.0))
        h2_produced = (efficiency * used_power) / self.H2_LHV_KWH_PER_KG

        self.h2_total += h2_produced
        return {
            "power_used_kw": round(used_power, 2),
            "efficiency": round(efficiency, 6),
            "h2_produced_kg": round(h2_produced, 4),
            "h2_total_kg": round(self.h2_total, 4),
        }
