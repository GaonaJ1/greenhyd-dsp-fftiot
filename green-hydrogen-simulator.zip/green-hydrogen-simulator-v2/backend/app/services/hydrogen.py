"""Business-logic service: real-time single-step plant telemetry."""

import time

from app.models.electrolyzer import PEMElectrolyzer
from app.simulation.power import solar_wind_profile


class HydrogenPlantService:
    """Stateful service that emits one snapshot per call to ``step()``.

    Useful for a live dashboard that polls every second.
    """

    def __init__(self):
        self._electrolyzer = PEMElectrolyzer()
        self._tick: int = 0

    def step(self) -> dict:
        power = solar_wind_profile(self._tick)
        e_step = self._electrolyzer.step(power)
        self._tick += 1

        return {
            "energy": {
                "solar": {"power": round(power * 0.6, 1), "voltage": 300.0},
                "wind": {"power": round(power * 0.4, 1), "voltage": 690.0},
            },
            "electrolyzer": {
                "current": round(e_step["power_used_kw"] / 300, 2),
                "hydrogen_rate": e_step["h2_produced_kg"],
                "oxygen_rate": round(e_step["h2_produced_kg"] * 8, 4),
                "efficiency": e_step["efficiency"],
            },
            "cfd": {"pressure": 101_325.0, "velocity": 1.2},
            "valves": {"H2": {"flow": round(e_step["h2_produced_kg"] * 10, 2), "position": 0.5}},
            "circuit": {"main_bus": {"current": round(e_step["power_used_kw"] / 300, 2), "voltage_drop": 5.0}},
            "sensors": {
                "pressure": {
                    "value": 101_325.0,
                    "unit": "Pa",
                    "timestamp": time.time(),
                    "sensor_id": "P-001",
                }
            },
        }
