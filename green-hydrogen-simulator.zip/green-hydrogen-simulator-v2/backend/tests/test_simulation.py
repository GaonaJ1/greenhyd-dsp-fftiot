"""Tests for the SimPy simulation engine."""

from app.simulation.engine import run_simulation
from app.simulation.power import constant_profile


class TestSimulationEngine:
    def test_returns_correct_hours(self):
        results = run_simulation(hours=10)
        assert len(results) == 10

    def test_time_increments(self):
        results = run_simulation(hours=5)
        times = [r["time_h"] for r in results]
        assert times == [0, 1, 2, 3, 4]

    def test_h2_total_increases(self):
        results = run_simulation(hours=5, rated_power_kw=500)
        totals = [r["h2_total_kg"] for r in results]
        assert all(b >= a for a, b in zip(totals, totals[1:]))

    def test_custom_power_fn(self):
        fn = lambda h: 300.0
        results = run_simulation(hours=3, power_fn=fn)
        for r in results:
            assert r["power_kw"] == 300.0
