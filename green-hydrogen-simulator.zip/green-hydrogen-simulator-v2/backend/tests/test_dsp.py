"""Tests for the DSP AM + radar signal processing pipeline."""

import numpy as np
from app.simulation.dsp_signals import (
    amplitude_modulation,
    add_awgn,
    envelope_detection,
    lowpass_filter,
    signal_statistics,
    run_dsp_pipeline,
)


class TestCoreSignals:
    def test_am_modulation_shape(self):
        m = np.sin(np.linspace(0, 2 * np.pi, 100))
        c = np.sin(np.linspace(0, 20 * np.pi, 100))
        s = amplitude_modulation(m, c)
        assert s.shape == m.shape

    def test_awgn_changes_signal(self):
        sig = np.zeros(1000)
        noisy = add_awgn(sig, sigma=1.0)
        assert np.std(noisy) > 0.5

    def test_envelope_positive(self):
        sig = np.sin(np.linspace(0, 10, 500))
        env = envelope_detection(sig)
        assert np.all(env >= 0)


class TestDSPPipeline:
    def test_returns_all_keys(self):
        result = run_dsp_pipeline(fs=1000, duration=0.1, downsample=1)
        assert "params" in result
        assert "time" in result
        assert "signals" in result
        assert "stats" in result

    def test_signal_keys(self):
        result = run_dsp_pipeline(fs=1000, duration=0.1)
        sigs = result["signals"]
        for key in ("modulating", "carrier", "am_modulated", "am_noisy",
                     "recovered", "radar_raw", "radar_processed",
                     "amplified", "gated", "shaped"):
            assert key in sigs

    def test_stats_structure(self):
        result = run_dsp_pipeline(fs=1000, duration=0.1)
        for name in ("am_noisy", "recovered", "final_shaped"):
            s = result["stats"][name]
            assert "mean" in s and "std" in s and "rms" in s
