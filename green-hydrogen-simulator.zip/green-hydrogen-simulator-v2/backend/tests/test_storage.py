"""Tests for the hydrogen storage tank."""

from app.simulation.storage import HydrogenStorage


class TestHydrogenStorage:
    def test_store_within_capacity(self):
        s = HydrogenStorage(capacity_kg=100)
        stored = s.store(50)
        assert stored == 50
        assert s.level == 50

    def test_store_clamps_at_capacity(self):
        s = HydrogenStorage(capacity_kg=100)
        s.store(80)
        stored = s.store(50)
        assert stored == 20
        assert s.level == 100

    def test_fill_fraction(self):
        s = HydrogenStorage(capacity_kg=200)
        s.store(100)
        assert s.fill_fraction == 0.5
