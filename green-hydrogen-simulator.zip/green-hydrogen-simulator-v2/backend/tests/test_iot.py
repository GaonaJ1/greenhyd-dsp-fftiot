"""Tests for the IoT sensor monitoring simulation."""

from app.simulation.iot_sensors import run_iot_simulation, _classify


class TestClassify:
    def test_levels(self):
        assert _classify(0.5) == "very_low"
        assert _classify(1.5) == "low"
        assert _classify(2.5) == "medium"
        assert _classify(3.5) == "high"  # clamped to 3


class TestIoTSimulation:
    def test_returns_correct_hours(self):
        r = run_iot_simulation(hours=10)
        assert len(r) == 10

    def test_time_increments(self):
        r = run_iot_simulation(hours=5)
        assert [x["time_h"] for x in r] == [0, 1, 2, 3, 4]

    def test_has_required_keys(self):
        r = run_iot_simulation(hours=1)
        keys = r[0].keys()
        for k in ("temperature", "light", "led_state", "stack_depth", "queue_processed"):
            assert k in keys

    def test_stack_grows(self):
        r = run_iot_simulation(hours=10)
        assert r[-1]["stack_depth"] == 10

    def test_led_activates_on_high_temp(self):
        r = run_iot_simulation(hours=24, temp_base=35.0, temp_threshold=30.0)
        # At base 35 most readings should trigger LED
        led_on = sum(1 for x in r if x["led_state"])
        assert led_on > len(r) * 0.5
