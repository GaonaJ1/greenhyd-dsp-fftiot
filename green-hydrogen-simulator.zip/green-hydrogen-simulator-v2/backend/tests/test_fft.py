"""Tests for FFT-based anomaly detection."""

import numpy as np
from app.simulation.fft_analysis import (
    generate_sensor_signal,
    compute_fft,
    analyze_spectrum,
    frequency_axis,
    run_fft_analysis,
)


class TestSignalGeneration:
    def test_default_length(self):
        t, sig = generate_sensor_signal(n=64)
        assert len(sig) == 64

    def test_custom_frequencies(self):
        t, sig = generate_sensor_signal(n=128, frequencies=[(10.0, 2.0)])
        assert len(sig) == 128
        assert np.max(np.abs(sig)) > 1.5  # amplitude ~2


class TestFFTComputation:
    def test_output_half_length(self):
        _, sig = generate_sensor_signal(n=64)
        mags, phases = compute_fft(sig)
        assert len(mags) == 32

    def test_pure_tone_peak(self):
        """A pure 5 Hz tone at 100 Hz sample rate → peak at bin 5*N/Fs."""
        n = 256
        sr = 100.0
        t, sig = generate_sensor_signal(n=n, sample_rate=sr, frequencies=[(5.0, 1.0)])
        mags, _ = compute_fft(sig)
        freqs = frequency_axis(n, sr)
        peak_idx = int(np.argmax(mags))
        assert abs(freqs[peak_idx] - 5.0) < 1.0  # within 1 Hz


class TestAnomalyDetection:
    def test_no_anomaly_below_threshold(self):
        result = run_fft_analysis(
            n=256, sample_rate=100, frequencies=[(5.0, 1.0)],
            anomaly_freq_threshold=15.0,
        )
        assert result["analysis"]["alert"] is False

    def test_anomaly_above_threshold(self):
        result = run_fft_analysis(
            n=256, sample_rate=100, frequencies=[(5.0, 1.0), (25.0, 0.8)],
            anomaly_freq_threshold=15.0,
        )
        assert result["analysis"]["alert"] is True
        assert len(result["analysis"]["anomalies"]) >= 1

    def test_external_signal(self):
        sig = [np.sin(2 * np.pi * 10 * i / 100) for i in range(128)]
        result = run_fft_analysis(external_signal=sig, sample_rate=100)
        assert len(result["time_domain"]["signal"]) == 128


class TestFullPipeline:
    def test_returns_all_sections(self):
        result = run_fft_analysis()
        assert "params" in result
        assert "time_domain" in result
        assert "frequency_domain" in result
        assert "analysis" in result
