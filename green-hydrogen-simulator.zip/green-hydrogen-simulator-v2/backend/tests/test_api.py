"""Integration tests for all API routes."""

from fastapi.testclient import TestClient
from jose import jwt

from app.config import settings
from app.main import app

client = TestClient(app)


def _token() -> str:
    return jwt.encode(
        {"sub": "test-user"},
        settings.jwt_secret,
        algorithm=settings.jwt_algorithm,
    )


AUTH = None  # populated in setup


def _auth():
    return {"Authorization": f"Bearer {_token()}"}


# ═════════════════════════════════════════════════════════════════════
#  Health
# ═════════════════════════════════════════════════════════════════════

class TestHealth:
    def test_health(self):
        r = client.get("/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"


# ═════════════════════════════════════════════════════════════════════
#  Auth guard  (shared across all protected endpoints)
# ═════════════════════════════════════════════════════════════════════

class TestAuthGuard:
    """Every protected endpoint must reject unauthenticated requests."""

    def test_step_requires_auth(self):
        assert client.get("/api/v1/step").status_code == 403

    def test_simulate_requires_auth(self):
        assert client.post("/api/v1/simulate").status_code == 403

    def test_iot_requires_auth(self):
        assert client.post("/api/v1/iot").status_code == 403

    def test_dsp_requires_auth(self):
        assert client.post("/api/v1/dsp").status_code == 403

    def test_fft_requires_auth(self):
        assert client.post("/api/v1/fft").status_code == 403


# ═════════════════════════════════════════════════════════════════════
#  Hydrogen — /api/v1/simulate  &  /api/v1/step
# ═════════════════════════════════════════════════════════════════════

class TestHydrogenSimulate:
    def test_default(self):
        r = client.post("/api/v1/simulate", headers=_auth())
        assert r.status_code == 200
        body = r.json()
        assert "points" in body and "summary" in body
        assert len(body["points"]) == settings.sim_hours

    def test_custom_hours(self):
        r = client.post("/api/v1/simulate", json={"hours": 5}, headers=_auth())
        assert r.status_code == 200
        assert len(r.json()["points"]) == 5

    def test_point_keys(self):
        r = client.post("/api/v1/simulate", json={"hours": 2}, headers=_auth())
        pt = r.json()["points"][0]
        for k in ("time_h", "power_kw", "h2_produced_kg", "h2_total_kg",
                   "storage_level_kg", "efficiency"):
            assert k in pt


class TestHydrogenStep:
    def test_snapshot(self):
        r = client.get("/api/v1/step", headers=_auth())
        assert r.status_code == 200
        body = r.json()
        for k in ("energy", "electrolyzer", "cfd", "valves", "sensors"):
            assert k in body


# ═════════════════════════════════════════════════════════════════════
#  IoT Sensor Monitoring — /api/v1/iot
# ═════════════════════════════════════════════════════════════════════

class TestIoTEndpoint:
    def test_default(self):
        r = client.post("/api/v1/iot", headers=_auth())
        assert r.status_code == 200
        body = r.json()
        assert "readings" in body and "summary" in body
        assert len(body["readings"]) == 48  # default hours

    def test_custom_hours(self):
        r = client.post("/api/v1/iot", json={"hours": 6}, headers=_auth())
        assert r.status_code == 200
        assert len(r.json()["readings"]) == 6

    def test_reading_keys(self):
        r = client.post("/api/v1/iot", json={"hours": 1}, headers=_auth())
        rd = r.json()["readings"][0]
        for k in ("temperature", "light", "led_state", "temp_class",
                   "light_class", "stack_depth", "queue_processed"):
            assert k in rd

    def test_summary_keys(self):
        r = client.post("/api/v1/iot", json={"hours": 5}, headers=_auth())
        s = r.json()["summary"]
        for k in ("temp_avg", "temp_min", "temp_max", "light_avg",
                   "led_on_hours", "led_on_pct"):
            assert k in s


# ═════════════════════════════════════════════════════════════════════
#  DSP Signal Processing — /api/v1/dsp
# ═════════════════════════════════════════════════════════════════════

class TestDSPEndpoint:
    def test_default(self):
        r = client.post("/api/v1/dsp", headers=_auth())
        assert r.status_code == 200
        body = r.json()
        assert "params" in body
        assert "signals" in body
        assert "stats" in body

    def test_signal_keys(self):
        r = client.post("/api/v1/dsp", headers=_auth())
        sigs = r.json()["signals"]
        for k in ("modulating", "carrier", "am_modulated", "am_noisy",
                   "recovered", "radar_raw", "radar_processed",
                   "amplified", "gated", "shaped"):
            assert k in sigs

    def test_custom_params(self):
        r = client.post("/api/v1/dsp", json={
            "fs": 2000, "duration": 0.5, "fm": 5, "fc": 200,
            "noise_sigma": 0.1, "downsample": 5,
        }, headers=_auth())
        assert r.status_code == 200

    def test_stats_have_rms(self):
        r = client.post("/api/v1/dsp", headers=_auth())
        for name in ("am_noisy", "recovered", "final_shaped"):
            assert "rms" in r.json()["stats"][name]


# ═════════════════════════════════════════════════════════════════════
#  FFT Anomaly Detection — /api/v1/fft
# ═════════════════════════════════════════════════════════════════════

class TestFFTEndpoint:
    def test_default(self):
        r = client.post("/api/v1/fft", headers=_auth())
        assert r.status_code == 200
        body = r.json()
        assert "time_domain" in body
        assert "frequency_domain" in body
        assert "analysis" in body

    def test_no_anomaly(self):
        r = client.post("/api/v1/fft", json={
            "frequencies": [{"frequency_hz": 5, "amplitude": 1.0}],
            "anomaly_freq_threshold": 15.0,
        }, headers=_auth())
        assert r.json()["analysis"]["alert"] is False

    def test_anomaly_detected(self):
        r = client.post("/api/v1/fft", json={
            "frequencies": [
                {"frequency_hz": 5, "amplitude": 1.0},
                {"frequency_hz": 25, "amplitude": 0.8},
            ],
            "anomaly_freq_threshold": 15.0,
        }, headers=_auth())
        assert r.json()["analysis"]["alert"] is True

    def test_external_signal(self):
        import math
        sig = [math.sin(2 * math.pi * 10 * i / 100) for i in range(128)]
        r = client.post("/api/v1/fft", json={
            "external_signal": sig,
            "sample_rate": 100,
        }, headers=_auth())
        assert r.status_code == 200
        assert len(r.json()["time_domain"]["signal"]) == 128

    def test_analysis_has_dominant(self):
        r = client.post("/api/v1/fft", headers=_auth())
        dom = r.json()["analysis"]["dominant"]
        assert "frequency_hz" in dom and "magnitude" in dom
