"""Tests for the PEM Electrolyzer model."""

import pytest
from app.models.electrolyzer import PEMElectrolyzer


class TestPEMElectrolyzer:
    def test_initial_efficiency(self):
        e = PEMElectrolyzer(efficiency=0.72)
        assert e.current_efficiency == 0.72

    def test_efficiency_degrades(self):
        e = PEMElectrolyzer(efficiency=0.72, degradation_rate=0.01)
        e.step(500)  # 1 hour
        assert e.current_efficiency < 0.72

    def test_efficiency_floor(self):
        e = PEMElectrolyzer(efficiency=0.72, degradation_rate=1.0, min_efficiency=0.55)
        e.step(500)
        assert e.current_efficiency == 0.55

    def test_power_clamped_to_rated(self):
        e = PEMElectrolyzer(rated_power_kw=500)
        result = e.step(9999)
        assert result["power_used_kw"] == 500.0

    def test_zero_power(self):
        e = PEMElectrolyzer()
        result = e.step(0)
        assert result["h2_produced_kg"] == 0.0

    def test_h2_accumulates(self):
        e = PEMElectrolyzer()
        r1 = e.step(400)
        r2 = e.step(400)
        assert r2["h2_total_kg"] > r1["h2_total_kg"]

    def test_negative_power_treated_as_zero(self):
        e = PEMElectrolyzer()
        result = e.step(-100)
        assert result["power_used_kw"] == 0.0
        assert result["h2_produced_kg"] == 0.0
