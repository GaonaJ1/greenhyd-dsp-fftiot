# Green Hydrogen Power Simulator

A digital-twin simulation platform for green hydrogen production systems with integrated IoT sensor monitoring, DSP signal processing, and FFT-based anomaly detection.

## Project Structure

```
green-hydrogen-simulator/
├── backend/
│   ├── app/
│   │   ├── api/routes.py               # All REST endpoints
│   │   ├── auth/token.py               # JWT authentication
│   │   ├── models/
│   │   │   ├── electrolyzer.py         # PEM electrolyzer physics
│   │   │   └── schemas.py              # Pydantic request/response models
│   │   ├── services/hydrogen.py        # Single-step plant telemetry
│   │   ├── simulation/
│   │   │   ├── engine.py               # SimPy H₂ production engine
│   │   │   ├── power.py                # Renewable power profiles
│   │   │   ├── storage.py              # Hydrogen tank model
│   │   │   ├── iot_sensors.py          # IoT sensor monitoring (DHT11+LDR)
│   │   │   ├── dsp_signals.py          # AM modulation + radar DSP
│   │   │   └── fft_analysis.py         # FFT anomaly detection
│   │   ├── config.py                   # Centralised settings
│   │   └── main.py                     # Application entry-point
│   ├── tests/
│   │   ├── test_api.py                 # Integration tests
│   │   ├── test_electrolyzer.py
│   │   ├── test_simulation.py
│   │   ├── test_storage.py
│   │   ├── test_iot.py
│   │   ├── test_dsp.py
│   │   └── test_fft.py
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/public/index.html          # Cesium 3D + dashboard
├── docs/architecture.md
├── docker-compose.yml
├── .env.example
└── .gitignore
```

## Quick Start

### Local development

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Docker

```bash
docker compose up --build
```

API: `http://localhost:8000` — Frontend: `http://localhost:3000` — Swagger: `http://localhost:8000/docs`

## API Endpoints

| Method | Path               | Auth | Description                                    |
|--------|--------------------|------|------------------------------------------------|
| GET    | `/health`          | No   | Health-check                                   |
| GET    | `/docs`            | No   | Interactive Swagger UI                         |
| GET    | `/api/v1/step`     | Yes  | Single time-step plant snapshot (dashboard)    |
| POST   | `/api/v1/simulate` | Yes  | Multi-hour H₂ production simulation (SimPy)   |
| POST   | `/api/v1/iot`      | Yes  | IoT sensor monitoring (temp + light + LED)     |
| POST   | `/api/v1/dsp`      | Yes  | AM modulation → demod → radar DSP pipeline    |
| POST   | `/api/v1/fft`      | Yes  | FFT spectrum analysis & anomaly detection      |

## Simulation Modules

### 1. Hydrogen Production (`/api/v1/simulate`)
PEM electrolyzer model with efficiency degradation, bounded H₂ storage tank, and stochastic solar/wind renewable power. Runs discrete-event simulation via SimPy.

### 2. IoT Sensor Monitoring (`/api/v1/iot`)
Software emulation of a Raspberry Pi system with DHT11 temperature sensor and LDR light sensor. Implements stack (LIFO), queue (FIFO), and hashmap classification. LED actuator fires on high-temp or low-light conditions.

### 3. DSP Signal Processing (`/api/v1/dsp`)
Full AM communication pipeline: modulating signal → carrier → AM modulation → AWGN noise → envelope detection → Butterworth LPF demodulation. Includes radar signal branch with resampling, DC blocking, amplifier, gate, and envelope shaping components.

### 4. FFT Anomaly Detection (`/api/v1/fft`)
Python port of the C++ Cooley-Tukey FFT system. Generates composite sensor signals (vibration-like), computes frequency spectrum, identifies dominant frequencies, and flags high-frequency anomalies above a configurable threshold.

## Environment Variables

Copy `.env.example` → `.env`:

| Variable          | Default         | Description              |
|-------------------|-----------------|--------------------------|
| `JWT_SECRET`      | (required)      | JWT signing key          |
| `JWT_ALGORITHM`   | `HS256`         | JWT algorithm            |
| `API_PORT`        | `8000`          | Backend listen port      |
| `CORS_ORIGINS`    | `*`             | Allowed CORS origins     |
| `SIM_HOURS`       | `48`            | Default simulation span  |

## Running Tests

```bash
cd backend
pytest -v
```

## License

MIT
